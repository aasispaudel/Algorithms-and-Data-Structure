let = [[i for i in range(j-1, j+1)] for j in range(10)]

print(
    [i for i in [j for j in let]]
)
